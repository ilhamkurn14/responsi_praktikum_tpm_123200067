package com.example.responsi_tpm_123200067

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
